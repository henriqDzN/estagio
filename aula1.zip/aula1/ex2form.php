<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>exercicios</title>
</head>

<body>
    <form action="ex2.php" action="" method="POST">
        <label for="number">Insira um numero:</label>
        <input type="number" name="numero" placeholder="">
        <label for="number">Insira outro numero:</label>
        <input type="number" name="numero2" placeholder="">
        <input type="submit" value="enviar">
    </form>
</body>

</html>