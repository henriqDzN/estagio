<?php
    $n1 = $_POST['nota1'];
    $n2 = $_POST['nota2'];
    $n3 = $_POST['nota3'];
    $array = [$n1,$n2,$n3];
    $notas = count($array);
    $soma = ($n1 + $n2 + $n3);
    $media = ($soma / $notas);
    $mediaformatada = number_format($media, 1);
    

    if ($media > 6) {
        echo "A média foi de $mediaformatada";
        echo " aluno aprovado". "<br>". "";
        echo  "N1 $n1 | N2 $n2 | N3 $n3 | MG $mediaformatada";

    }elseif($media <6) {
        echo "A média foi de $mediaformatada";
        echo " aluno reprovado". "<br>". "";
        echo  "N1 $n1 | N2 $n2 | N3 $n3 | MG $mediaformatada";
        
    }else {
        echo "aluno em recuperacao";
    }

?>