<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>exercicios</title>
</head>

<body>
    <form action="ex4.php" action="" method="POST">
        <label for="number">Insira um número de 1 a 12:</label>
        <input type="number" name="mes" placeholder="">
        <input type="submit" value="enviar">
    </form>
</body>

</html>