<?php
    $userValue1 = 5;
    $userValue2 = 5;
    $ope = array(
        'soma',
        'sub',
        'div',
        'mult'
);

    switch($ope) {
    case "soma":
    echo "aaa";
    break;
    }



?>