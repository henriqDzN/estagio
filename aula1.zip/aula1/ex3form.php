<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>exercicios</title>
</head>

<body>
    <form action="ex3.php" action="" method="POST">
        <label for="number">Insira a 1a Nota:</label>
        <input type="number" name="nota1" placeholder="">
        <label for="number">Insira a 2a Nota:</label>
        <input type="number" name="nota2" placeholder="">
        <label for="number">Insira a 3a Nota:</label>
        <input type="number" name="nota3" placeholder="">
        <input type="submit" value="enviar">
    </form>
</body>

</html>