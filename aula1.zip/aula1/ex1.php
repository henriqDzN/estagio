 <?php    
        if($_POST['numero'] > 1){
            echo "Valor Positivo";
        }elseif($_POST['numero'] < 0){
            echo "Valor negativo";
        }else {
            echo "Valor igual a zero";
        }
        ?>