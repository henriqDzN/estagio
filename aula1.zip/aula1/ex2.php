<?php
    $valorA = $_POST['numero'];
    $valorB = $_POST['numero2'];
    $resultado = array($valorA,$valorB);
    sort($resultado);

    foreach($resultado as $resultado) {
    echo $resultado ." | ";
    }
   

?>