<?php
$userinput = $_POST['mes'];
$array = [
    1 =>    'Janeiro',
            'Fevereiro',
            'Março',
            'Abril',
            'Maio',
            'Junho',
            'Julho',
            'Agosto',
            'Setembro',
            'Outubro',
            'Novembro',
            'Dezembro'
];


if (($userinput > 0) && ($userinput <= 12)) {
    echo "O Mês selecionado foi $array[$userinput]";
}else{
    echo "O Mês selecionado não existe";
}

?>